Hello, and thank your for supporting indie artist!

Package contains Spine2D animated character, that is using spine-unity runtimes, its free and you can find it in link bellow

http://en.esotericsoftware.com/spine-unity-download

There is also Baked Unity Native Animation, but it does't fully support spine features, Unity Native animation doesn't support alpha changes, mesh changes and draw order made in Spine Editor. 

Consider using spine-Unity runtimes for full experience!

Have fun!